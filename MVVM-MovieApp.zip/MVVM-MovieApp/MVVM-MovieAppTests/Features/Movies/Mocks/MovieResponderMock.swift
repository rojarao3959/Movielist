//
//  MovieResponderMock.swift
//  MVVM-MovieAppTests
//
//  Created by Rojarao Potham Shetty on 12/12/22.
//

import Foundation
@testable import MVVM_MovieApp

class MovieResponderMock: MovieResponder {
    var showMovieDetailsCount = 0
    var movie: Movie?
    func showMovieDetail(movie: Movie) {
        showMovieDetailsCount += 1
        self.movie = movie
    }
}
