//
//  MovieRepositoryMock.swift
//  MVVM-MovieAppTests
//
//  Created by Rojarao Potham Shetty on 12/12/22.
//

import Foundation
@testable import MVVM_MovieApp

class MoviesRespositoryMock: MoviesRepository {
    var movies: [Movie] = []
    var fetchError: FetchError? = nil
    var fetchMoviesCount = 0
    func fetchMovies(completion: @escaping (Result<[Movie], FetchError>) -> Void) {
        fetchMoviesCount += 1
        if let error = fetchError {
            completion(.failure(error))
            return
        }

        completion(.success(movies))
    }
}
