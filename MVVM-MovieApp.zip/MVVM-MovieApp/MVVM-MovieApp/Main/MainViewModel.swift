//
//  MainViewModel.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//

import Foundation

enum MainViewState {
    case movies
}

final class MainViewModel {
    var mainViewState: DynamicType<MainViewState> = DynamicType<MainViewState>()

    init() {
        mainViewState.value = .movies
    }
}
