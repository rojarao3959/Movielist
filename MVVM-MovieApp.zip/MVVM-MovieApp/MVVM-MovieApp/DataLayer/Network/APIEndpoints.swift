//
//  APIEndpoints.swift
//  MVVMTrendingMovies
//
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//

import Foundation

struct APIEndpoints {

    static func getWeeklyTrendingMovies() -> Endpoint {
        return Endpoint(path: "search/movie")
    }

    static func getMovieImage(path: String, width: Int) -> Endpoint {
        return Endpoint(path: "t/p/w\(width)\(path)", version: "")
    }
}
