//
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//
//

import Foundation

protocol MoviesRepository {
    func fetchMovies(completion: @escaping (Result<[Movie], FetchError>) -> Void)
}
