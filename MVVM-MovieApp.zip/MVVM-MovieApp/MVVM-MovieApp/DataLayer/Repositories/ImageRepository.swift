//
//  ImageRepository.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//
//

import UIKit

protocol ImageRepository {
    func fetchImage(with imagePath: String, width: Int, completion: @escaping (Result<UIImage, Error>) -> Void)
}
