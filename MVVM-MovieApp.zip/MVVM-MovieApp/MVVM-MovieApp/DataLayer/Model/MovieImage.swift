//
//  MovieImage.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//
//

import Foundation
import UIKit

struct MovieImage: Equatable {
    static func == (lhs: MovieImage, rhs: MovieImage) -> Bool {
        return lhs.image == rhs.image && lhs.size == rhs.size
    }

    let image: UIImage
    let size: Int
}
