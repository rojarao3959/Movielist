//
//  EmptyState.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//

import Foundation

struct FetchError: Error {
    let message: String
}
