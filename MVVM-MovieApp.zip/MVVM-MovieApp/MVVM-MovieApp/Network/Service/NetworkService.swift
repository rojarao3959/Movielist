//
//  NetworkSession.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//

import Foundation

protocol NetworkService {
    func requestData(with endpoint: Endpoint, completion: @escaping (Result<Data, NetworkError>) -> Void)
}
