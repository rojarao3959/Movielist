//
//  DefaultNetworkService.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//

import Foundation

protocol NetworkSession {
  func dataTask(with url: URLRequest, completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) -> URLSessionDataTask
}

extension URLSession: NetworkSession {}

final class DefaultNetworkService: NetworkService {
    private let session: NetworkSession
    private let config: NetworkConfig
    
    init(session: NetworkSession = URLSession.shared,
         config: NetworkConfig) {
        self.session = session
        self.config = config
    }

    func requestData(with endpoint: Endpoint, completion: @escaping (Result<Data, NetworkError>) -> Void) {
        guard let request = self.urlRequest(with: endpoint) else {
            return
        }

        session.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(.nonFatal(error: error)))
                    return
                }

                if let httpResponse = response as? HTTPURLResponse, !(200...299).contains(httpResponse.statusCode) {
                    completion(.failure(.httpError(statusCode: httpResponse.statusCode)))
                    return
                }

                guard let data = data else {
                    completion(.failure(.noContentReturned))
                    return
                }

                completion(.success(data))
            }
        }.resume()
    }

    private func urlRequest(with endpoint: Endpoint) -> URLRequest? {
        var urlComponents = URLComponents(string: config.baseURL.absoluteString)
        urlComponents?.path =  "/\(endpoint.version)/\(endpoint.path)"
        urlComponents?.query = "api_key=7e588fae3312be4835d4fcf73918a95f&query=a%20&page=01"
        let urlfinal = urlComponents?.url?.absoluteString.removingPercentEncoding
        let fileUrl = URL(string: urlfinal!)
        guard let url = fileUrl else {
            return nil
        }

        return URLRequest(url: url)
    }
}

