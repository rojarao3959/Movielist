//
//  MovieListItemViewModel.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//

import Foundation
import UIKit

final class MovieListCellViewModel {
    private let movie: Movie
    private let imageRepository: ImageRepository

    var movieTitle: String {
        return movie.title
    }

    var releaseDate: String {
        return movie.releaseDate
    }

    var popularity: Float {
        return movie.popularity
    }

    init(movie: Movie, imageRepository: ImageRepository) {
        self.movie = movie
        self.imageRepository = imageRepository
    }

    func getImage(with width: Int, completion: @escaping (UIImage?) -> Void) {
        imageRepository.fetchImage(with: movie.posterImageURLPath,
                                   width: width) { result in
            switch result {
            case .success(let image):
                completion(image)
            case .failure:
                completion(nil)
            }
        }
    }
}
