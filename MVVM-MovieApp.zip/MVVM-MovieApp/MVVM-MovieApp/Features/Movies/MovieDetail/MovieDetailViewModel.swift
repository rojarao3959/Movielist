//
//  MovieDetailViewModel.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//

import Foundation
import UIKit

final class MovieDetailViewModel {
    enum Section: CaseIterable {
        case image
        case movieDetail
    }

    private let movie: Movie

    var sectionCount: Int {
        return  Section.allCases.count
    }

    var moviePosterURL: String {
        return movie.posterImageURLPath
    }

    let sections = Section.allCases

    init(movie: Movie) {
        self.movie = movie
    }
}
