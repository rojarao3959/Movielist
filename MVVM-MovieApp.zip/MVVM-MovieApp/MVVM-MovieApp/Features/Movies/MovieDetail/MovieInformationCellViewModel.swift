//
//  MovieDetailCellViewModel.swift
//  MVVM-MovieApp
//
//  Created by Rojarao Pothams Setty 12/12/2022
//

import Foundation

final class MovieInformationCellViewModel {
    private let movie: Movie

    var movieTitle: String {
        return movie.title
    }

    var releaseDate: String {
        return movie.releaseDate
    }

    var movieOverview: String {
        return movie.overview
    }

    var popularity: Float {
        return movie.popularity
    }

    init(movie: Movie) {
        self.movie = movie
    }
}
